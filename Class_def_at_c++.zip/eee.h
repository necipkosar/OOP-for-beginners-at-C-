#include<iostream>
#include<math.h>
#define M_PI 3.14

using namespace std;

/*Resistors in Series*/
class first
{
public:
	double R1,R2,R3;
	double Req();
};

double first::Req()
{
	double REQ;
	REQ = R1 + R2 + R3;
	return REQ;
}

/*Resistors in Parallel*/
class second
{
public:
	double i, n, x, R;
	double Rtotal();
};

double second::Rtotal()
{
	double RTOTAL;
	for (int i = 0; i < n; i++)
	{
		RTOTAL += 1 / x[i];
	}
	return 1 / RTOTAL;
}

/*Capacitive Reactance*/
class third
{
public:
	double f, C;
	double Xc();

};

double third::Xc()
{
	double Xcap;
	Xcap = 1 / (2 * M_PI * f * C);
	return Xcap;
}

/*Ohm's Law for AC*/

class fourth
{
public:
	double E, I, Z;
	double Evoltage();
	double Zimpadance();
	double Icurrent();
};

double fourth::Evoltage()
{
	double Evol;
	Evol = I * Z;
	return Evol;
}

double fourth::Zimpadance()
{
	double Zimp;
	Zimp = E / I;
	return Zimp;
}

double fourth::Icurrent()
{
	double Icur;
	Icur = E / Z;
	return Icur;
}

