﻿#include <iostream>
#include "eee.h"
#include <math.h>

first fi;
second s;
third t;
fourth f;

using namespace std;

int selection;

void first_formula()
{
	
	cout << "enter R1= ";
	cin >> fi.R1;
	cout << "enter R2= ";
	cin >> fi.R2;
	cout << "enter R3= ";
	cin >> fi.R3;

	cout << "\n first formula= " << fi.Req();

}

void second_formula()
{
	cout << "How many resistors are there?= ";
	cin >> s.n;
	s.x = new double[(int)s.n];

	for (int i = 0; i < s.n; i++)
	{
		cout << "enter R: ";
		cin >> s.x[i];
	}

	cout << "\n second formula= " << s.Rtotal();
}

void third_formula()
{
	cout << "enter f: ";
	cin >> t.f;
	cout << "enter C: ";
	cin >> t.C;

	cout << "\n third formula= " << t.Xc();
}

void fourth_formula()
{
	cout << "enter E: ";
	cin >> fo.E;
	cout << "enter I: ";
	cin >> fo.I;
	cout << "enter Z: ";
	cin >> fo.Z;

	cout << "\n E(Voltage)= " << fo.Evoltage();
	cout << "\n Z(Impadance)= " << fo.Zimpadance();
	cout << "\n I(Current)= " << fo.Icurrent();
	

}

void selection_read()
{
	cout << "---THANKS TO Prof. Dr. KAAN ERARSLAN---\n---DEVELOPED BY NECİP KOŞAR---";
	cout << "\n\n 1.Resistor in Series \n 2.Resistor in Parallel \n 3.Capacitive Reactance \n 4.Ohm's Law For AC \n 5.Exit ";
	cout << "\n\n Your selection: ";
	cin >> selection;
}

void main()
{
	do

	{
		selection_read();
		switch (selection)
		{
		case 1: first_formula();
			break;
		case 2: second_formula();
			break;
		case 3: third_formula();
			break;
		case 4: fourth_formula();
			break;
		default:cout << "\n\n Incorrect Entry...! \a\a\a";

		}
	} while (selection != 5);
	
}

